const initialState = {
    result: null
}

export default ( state = initialState, action ) => {
    switch(action.type) {
        case 'GET_QUIZ_SUCCESS':
            return {...state, result: action.payload && action.payload.results }
        default:
            return state;
    }
}