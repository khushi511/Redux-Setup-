import React, { Component } from 'react'
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { getQuizData } from './action';
import {Redirect} from 'react-router-dom';

class Quiz extends Component {

    componentWillReceiveProps(nextProps) {
       if(nextProps.isResult) {
           this.forceUpdate();
       }
    }

    render() {
        if(this.props.isResult) {
            return <Redirect to="/questions"/>
        }
        return (
            <section>
                <div>
                    <h2>Welcome</h2>
                    <button onClick={this.props.getQuizData}>Start test</button>
                </div>
            </section>
        )
    }
}
const mapStateToProps = state => ({
    isResult: !!state.quiz.result
});

const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        getQuizData
    }, dispatch);
}
export default connect(mapStateToProps, mapDispatchToProps)(Quiz);