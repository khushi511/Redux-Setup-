export const getQuizData = () => dispatch => {
    let url = "https://opentdb.com/api.php?amount=10&difficulty=hard&type=boolean";
        fetch(url)
        .then(res => res.json())
        .then(response => {
            dispatch({
                type: 'GET_QUIZ_SUCCESS',
                payload: response
            })
        })
}