import React, { Component } from 'react';
import { connect } from 'react-redux';

class Questions extends Component {
    render() {
        const questions = this.props.result;
        return (
            <div>
                {
                    questions && questions.map((item , i) => {
                        return (
                            <div>
                                <span>{i}</span><h5>{item.question}</h5><br/>
                            </div>
                        )
                    })
                }
            </div>
        )
    }
}

const mapStateToProps = state => ({
    result: state.quiz.result
});

export default connect(mapStateToProps)(Questions);
