import React, { Component } from 'react';
import { connect } from 'react-redux';

class Questions extends Component {
    state = {
        correctAnswerCount: 0
    };

    onClickRadioButton = (e, item) => {
        const value = e.target.value;
        const name = e.target.name;
        const correctAnswer = item['correct_answer'] == value ? this.state.correctAnswerCount++ : this.state.correctAnswerCount;
        this.setState({[name]: value, correctAnswer});
    }

    isChecked = (name, value) => {
        return (this.state[name] && this.state[name] == value);
    }

    render() {
        const questions = this.props.result;
        return (
            <div>
                {
                    questions && questions.map((item , i) => {
                        return (
                            <div>
                                <span>Qusetion No: {i}</span><h5>{item.question}</h5><br/>
                                <div onClick={e => this.onClickRadioButton(e, item)}>
                                    <input type="radio" name={"question_" + i} value="True" checked={this.isChecked('gender', 'True')} />True <br/>
                                    <input type="radio" name={"question_" + i} value="False" checked={this.isChecked('gender', 'False')} /> False <br/>
                                </div>
                            </div>
                        )
                    })
                }
                <p>Correct Answer-----{this.state.correctAnswerCount}</p>
            </div>
        )
    }
}

const mapStateToProps = state => ({
    result: state.quiz.result
});

export default connect(mapStateToProps)(Questions)



