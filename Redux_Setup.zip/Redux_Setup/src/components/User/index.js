import React, { Component } from 'react';

const User = ({ match }) => {
    return(
       <section>
           <div>
           <h2>Welcome</h2>
            <button>Start test</button>
           </div>
       </section>
    )
}

export default User;
