import React, { Component } from 'react';
import './index.scss'

export default class Dropdown extends Component {
    state = {
        show: false,
        value: ''
    }
    showStyle = {
        position: "relative",
        transform: "translate3d(0, 0, 0)",
        top: "-16px",
        left: "unset",
        display: "block"
    }
    toggleDropdown = () => {
        this.setState({
            show: !this.state.show
        })
    }
    hideDropdownMenuOnOutsideClick = () => {
        if (this.state.show) {
            this.setState({
                show: !this.state.show
            })
        }
    }

    onSelect = (e) => {
        debugger;
        if (e.target.nodeName == "LI") {
            let idVal = e.target.attributes["data-value"].nodeValue;
            let value = idVal != "-1" ? e.target.innerText : "";
            this.setState({
                value,
                show: !this.state.show
            })
        }
    }
    // componentDidMount() {
    //     document.addEventListener("click", this.hideDropdownMenuOnOutsideClick);
    // }
    // componentWillUnmount() {
    //     document.removeEventListener("click", this.hideDropdownMenuOnOutsideClick)
    // }
    render() {
        return (
            <div className="dropdown-wrapper">
                <label className={this.state.value ? "shrink":"expand"}>Test label</label>
                <div className={"dropdown"}>
                    <button className="btn" onClick={this.toggleDropdown} type="button" aria-haspopup="true" aria-expanded="false">
                        {this.state.value}
                    </button>
                    <ul className={"dropdown-menu"} onClick={this.onSelect} style={this.state.show ? this.showStyle : {}} >
                        <li className="dropdown-item" data-value="-1">none</li>
                        <li className="dropdown-item" data-value="1">Action</li>
                        <li className="dropdown-item" data-value="2">Another action</li>
                        <li className="dropdown-item" data-value="3">Something else here</li>
                    </ul>
                </div>
            </div>
        )
    }
}
