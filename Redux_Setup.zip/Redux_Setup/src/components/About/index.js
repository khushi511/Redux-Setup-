import React, { Component } from 'react';

export default class About extends Component {
    render() {
        return(
            <div>
                Hi I am About us Page
            </div>
        )
    }
}