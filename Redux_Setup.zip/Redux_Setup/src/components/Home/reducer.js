const initialState = {
    name: "Khushi",
    age: 26,
    town: 'pune'
}

export default (state = initialState, action) => {
    switch(action.type) {
        case 'SET_INITIAL_DETAIL':
            return {...state, name: action.payload.name, age: action.payload.age}
        default: 
            return state
    }
}