export const changePersonalDetails = data => ({
        type: "SET_INITIAL_DETAIL",
        payload: data
})