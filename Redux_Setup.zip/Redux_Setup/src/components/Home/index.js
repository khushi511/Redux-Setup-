import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { changePersonalDetails } from './action';
import DropDown from '../About/DropDown';

class Home extends Component {
    state = {
        name: "Initial",
        age: 1
    }

    changeDetails = () => {
        let data = { name: 'John', age: 18 };
        this.setState(data);
        this.props.changePersonalDetails(data);
    }

    render() {
        return (
            <div>
                <p className="text-color">{`name: ${this.props.personalDetails.name} age: ${this.props.personalDetails.age}`}
                </p>
                <h2>From State</h2>
                <p className="text-color">{`name: ${this.state.name || ''} age: ${this.state.age || ''}`}</p>
                <a onClick={this.changeDetails}>Click to change</a>
                <DropDown />
            </div>
        );
    }
}

const mapStateToProps = state => ({
    personalDetails: state.personalDetails
})

const mapDispatchToProps = dispatch => bindActionCreators({
    changePersonalDetails
}, dispatch);


export default connect(mapStateToProps, mapDispatchToProps)(Home);





