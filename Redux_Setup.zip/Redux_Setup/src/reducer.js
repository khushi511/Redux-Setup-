import { combineReducers } from 'redux';
import personalDetails from './components/Home/reducer';
import quiz from './components/Quiz/reducer';

export default combineReducers({
    personalDetails,
    quiz
})


