import { createStore, applyMiddleware } from 'redux';
import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import rootReducer from './reducer';
import thunk from 'redux-thunk';
import Route from './route';

const store = createStore(
    rootReducer, 
    applyMiddleware(thunk)
);

render(
    <Provider store={store}>
       <Route />
    </Provider>
    , document.getElementById('root'))
