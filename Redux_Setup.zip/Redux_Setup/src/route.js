import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './components/Home';
import About from './components/About';
import User from './components/User';
import Quiz from './components/Quiz';
import Questions from './components/Quiz/Questions';

export default () => (
    <Router>
        <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/about" component={About} />
            <Route path="/quiz" component={Quiz} />
            <Route path="/questions" component={Questions} />
            <Route path="/:user" component={User} />
        </Switch>
    </Router>
)

